import os
import streamlit as st
import pandas as pd
import plotly.express as px
from dotenv import load_dotenv
from bs4 import BeautifulSoup
from azure.ai.textanalytics import TextAnalyticsClient
from azure.core.credentials import AzureKeyCredential

# 1. Configurações Iniciais da Página
st.set_page_config(page_title="Dashboard de Sentimentos - Sabor & Dados", layout="wide")
load_dotenv()

# 2. Autenticação Azure
@st.cache_resource # Cache para não reautenticar a cada clique
def autenticar_azure():
    endpoint = os.getenv("AZURE_AI_ENDPOINT")
    key = os.getenv("AZURE_AI_KEY")
    if not key or not endpoint:
        st.error("❌ Chaves da Azure não encontradas no arquivo .env")
        st.stop()
    return TextAnalyticsClient(endpoint, AzureKeyCredential(key))

client_azure = autenticar_azure()

# 3. Função para Extrair Comentários do HTML Local
def extrair_comentarios_html():
    try:
        with open("index.html", "r", encoding="utf-8") as f:
            html_content = f.read()
        soup = BeautifulSoup(html_content, "html.parser")
        # Captura as tags <p class="texto-comentario"> geradas pelo JS
        tags = soup.find_all("p", class_="texto-comentario")
        
        # Se o BeautifulSoup não ler o JS, usamos os dados estáticos do backup
        textos = [tag.get_text() for tag in tags]
        if not textos:
             # Dados de backup (caso o scraping falhe no HTML dinâmico)
             textos = [
                "A comida estava absolutamente divina! O tempero estava perfeito.",
                "Minha comida chegou fria e o serviço foi extremamente lento.",
                "Os pratos são criativos e bem executados. Ambiente moderno.",
                "O Tiramisu estava muito aquoso e sem o sabor característico.",
                "O preço é justo para a qualidade, mas o serviço poderia ser mais atencioso."
            ]
        return textos
    except FileNotFoundError:
        st.error("❌ Arquivo 'index.html' não encontrado na pasta do projeto.")
        st.stop()

# 4. Função para Analisar Sentimentos com Azure
def analisar_sentimentos(textos):
    with st.spinner('🤖 IA da Microsoft analisando comentários...'):
        response = client_azure.analyze_sentiment(documents=textos, language="pt")
        
        dados_analisados = []
        for i, doc in enumerate(response):
            dados_analisados.append({
                "Comentário": textos[i],
                "Sentimento": doc.sentiment.upper(),
                "Positivo": doc.confidence_scores.positive,
                "Negativo": doc.confidence_scores.negative,
                "Neutro": doc.confidence_scores.neutral
            })
        return pd.DataFrame(dados_analisados)

# --- INTERFACE GRÁFICA (STREAMLIT) ---

# Título e Subtítulo
st.title("🍽️ Dashboard de Feedback do Restaurante Sabor & Dados")
st.subheader("Análise de Sentimentos Automatizada com Azure AI")

# Botão para Iniciar a Análise
if st.button('🚀 Iniciar Análise do Site Local'):
    
    # Executa o Pipeline
    comentarios_puros = extrair_comentarios_html()
    df_sentimentos = analisar_sentimentos(comentarios_puros)

    # --- ÁREA DO DASHBOARD ---
    st.divider()
    
    # 1. Métricas Principais (Cards)
    col1, col2, col3, col4 = st.columns(4)
    total = len(df_sentimentos)
    pos = len(df_sentimentos[df_sentimentos['Sentimento'] == 'POSITIVE'])
    neg = len(df_sentimentos[df_sentimentos['Sentimento'] == 'NEGATIVE'])
    neu = len(df_sentimentos[df_sentimentos['Sentimento'] == 'NEUTRAL'])

    col1.metric("Total de Avaliações", total)
    col2.metric("✅ Positivas", pos, f"{(pos/total)*100:.0f}%")
    col3.metric("😡 Negativas", neg, f"{(neg/total)*100:.0f}%")
    col4.metric("😐 Neutras", neu, f"{(neu/total)*100:.0f}%")

    st.divider()

    # 2. Gráficos
    graf1, graf2 = st.columns([1, 2])

    with graf1:
        st.write("### Distribuição de Sentimentos")
        fig_pizza = px.pie(df_sentimentos, names='Sentimento', 
                           color='Sentimento',
                           color_discrete_map={'POSITIVE':'#2A5B3E', 'NEGATIVE':'#C53030', 'NEUTRAL':'#D4A762'},
                           hole=0.4)
        st.plotly_chart(fig_pizza, use_container_width=True)

    with graf2:
        st.write("### Pontuação de Confiança por Comentário")
        fig_barra = px.bar(df_sentimentos, x=df_sentimentos.index + 1, y=["Positivo", "Negativo", "Neutro"],
                           title="Análise Detalhada dos Scores de IA",
                           labels={"value": "Score de Confiança (0 a 1)", "x": "ID do Comentário"},
                           color_discrete_map={'Positivo':'#2A5B3E', 'Negativo':'#C53030', 'Neutro':'#D4A762'},
                           barmode="group")
        st.plotly_chart(fig_barra, use_container_width=True)

    # 3. Tabela Detalhada com Cores
    st.write("### Detalhes das Avaliações")
    
    def colorir_sentimento(val):
        color = '#2A5B3E' if val == 'POSITIVE' else '#C53030' if val == 'NEGATIVE' else '#D4A762'
        return f'background-color: {color}; color: white; font-weight: bold'

    st.dataframe(df_sentimentos.style.applymap(colorir_sentimento, subset=['Sentimento']), use_container_width=True)

else:
    st.info("Clique no botão acima para carregar o site local e iniciar a análise da IA.")